<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Analyst Jr - KRA_2017-18</title>
<link rel="stylesheet" type="text/css" href="datastylesheet.css" />
<script src="source.js"></script>
<script src="valid.js"></script>
</head>
<body>
<div id="wrapper">
<div class="header">
<div class="qms">
<h3>Analyst Jr - KRA_2017-18</h3>
</div>
<div class="apprisal">
<div class="para" id="fm">
<p>Parameters</p>
</div>
<div class="rating">
<p>Rating</p>
</div>
<div class="quality">
<div class="box1">
<p>Jr Analyst</p>
</div>
<div class="box2">
<div class="min">
<p>min</p>
</div>
<div class="max">
<p>max</p>
</div>
<div class="Weightage">
<p>Weightage</p>
</div>
</div>
</div>
</div>
<!--fist set start-->
<div class="cont">
<div class="cn1">
<p>External Quality </p>
</div>
<div class="cn3">
<table>
<tr>
<td>Outstanding</td>
</tr>
<tr>
<td>Exceeds Expectations</td>
</tr>
<tr>
<td>Meets Expectations</td>
</tr>
<tr>
<td>Mostly Meets Expectations</td>
</tr>
<tr>
<td class="ark">Does not Meet Expectations</td>
</tr>
</table>
</div>
<div class="cn4">
<div class="cn5">
<table class="score">
<tr>
<td colspan="2">Above 99.51%</td>
</tr>
<tr>
<td>98.76%</td>
<td>99.50%</td>
</tr>
<tr>
<td>97.76%</td>
<td>98.75%</td>
</tr>
<tr>
<td>96.01%</td>
<td>97.75%</td>
</tr>
<tr>
<td class="ark" colspan="2">
Below 96.00%</td>
</tr>
</table>
</div>
<div class="cn6">
<div class="hrw">
<p>40%</p>
</div>
</div>
</div>
<div class="message">
<form name="fname" onsubmit="return validateForm()" method="post" action="insert.php">

<div class="num">
<input type="text" name="employee" id="employee" autocomplete="off" placeholder="Employee Id"><em id="info"></em>
<input type="text" class="rbm" name="production" autocomplete="off" id="parameters" onkeyup=myFunction();><em id="base"></em>
</div>
<div class="mark">
<input type="text" id="score" autocomplete="off" name="value1">
</div>
<div class="dis" id="description">
<input type="text" class="area" autocomplete="off" name="value2"><em id="base2"></em>
</div>
</div>
</div>
<div class="spc">
</div>
<!--first set End-->
<!--second star-->
<div class="second">
<div class="cont">
<div class="cn1">
<p>Productivity</p>
</div>
<div class="cn3">
<table>
<tr>
<td>Outstanding</td>
</tr>
<tr>
<td>Exceeds Expectations</td>
</tr>
<tr>
<td>Meets Expectations</td>
</tr>
<tr>
<td>Mostly Meets Expectations</td>
</tr>
<tr>
<td class="ark">Does not Meet Expectations</td>
</tr>
</table>
</div>
<div class="cn4">
<div class="cn5">
<table class="score">
<tr>
<td colspan="2">Above 20.51%</td>
</tr>
<tr>
<td>19.01</td>
<td>20.50</td>
</tr>
<tr>
<td>18.01</td>
<td>19.00</td>
</tr>
<tr>
<td>16.51</td>
<td>18.00</td>
</tr>
<tr>
<td class="ark" colspan="2">Below 16.50</td>
</tr>
</table>
</div>
<div class="cn6">
<div class="hrw">
<p>40%</p>
</div>
</div>
</div>
<div class="message">
<div class="num">
<input type="text" class="rbm" name="quality" autocomplete="off" id="ark" onkeyup=gama();><em id="base3"></em>
</div>
<div class="mark">
<input type="text" name="value3" autocomplete="off" id="ssm">
</div>
<div class="dis" id="max">
<input type="text" name="value4" autocomplete="off" class="area"><em id="base4"></em>
</div>
</div>
</div>
</div>
<div class="spc">
</div>
<!--end-->
<div class="second">
<div class="cont">
<div class="cn1">
<p>Attendance</p>
</div>
<div class="cn3">
<table>
<tr>
<td>Outstanding</td>
</tr>
<tr>
<td>Exceeds Expectations</td>
</tr>
<tr>
<td>Meets Expectations</td>
</tr>
<tr>
<td>Mostly Meets Expectations</td>
</tr>
<tr>
<td class="ark">Does not Meet Expectations</td>
</tr>
</table>
</div>
<div class="cn4">
<div class="cn5">
<table class="score">
<tr>
<td colspan="2">0 Instance</td>
</tr>
<tr>
<td>1 Instance</td>
</tr>
<tr>
<td>2 Instance</td>
</tr>
<tr>
<td>3 Instance</td>
</tr>
<tr>
<td class="ark" colspan="2">> 3 Instance</td>
</tr>
</table>
</div>
<div class="cn6">
<div class="hrw">
<p>20%</p>
</div>
</div>
</div>
<div class="message">
<div class="num">
<input type="text" class="rbm" name="certification" autocomplete="off" id="before" onkeyup=sky();><em id="base5"></em>
</div>
<div class="mark">
<input type="text" name="value5" autocomplete="off" id="alpha">
</div>
<div class="dis" id="marks">
<input type="text" class="area" name="value6" autocomplete="off" >
</div>
</div>
</div>
</div>
<!--first set End-->
<!--second star-->
<!--end-->
</div>
<div class="foot">
<div class="final">
<p> Total%<span class="dino"> 100%</span></p>
</div>
<div class="give">
<input type="submit" autocomplete="off" name="submit" value="SUBMIT" id="save">
</div>
</div>
</div>
</body>
</html>
