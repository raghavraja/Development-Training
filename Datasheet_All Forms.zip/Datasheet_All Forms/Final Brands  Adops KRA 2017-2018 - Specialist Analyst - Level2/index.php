<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Exec\Sen Analyst - KRA-2017-18</title>
<link rel="stylesheet" type="text/css" href="datastylesheet.css" />
<script src="source.js"></script>
<script src="valid.js"></script>
</head>
<body>
<div id="wrapper">
<div class="header">
<div class="qms">
<h4>2adpro</h4>
</div>
<div class="qms2">
<h4>KRA/KPIs for 2017-18</h4>
</div>
<div class="apprisal">
<div class="para">
<p>Parameters</p>
</div>
<div class="rating">
<p>Rating</p>
</div>
<div class="quality">
<div class="box1">
<p>Specialist Analyst/<br>
Specialist Designer/<br>
Specialist Quality Controller/<br>
Specialist Image Artist<br>
(LEVEL 2)</p>
</div>
<div class="box2">
<div class="min">
<p>min</p>
</div>
<div class="max">
<p>max</p>
</div>
<div class="Weightage">
<p>Weightage</p>
</div>
</div>
</div>
</div>
<!--fist set start-->
<div class="cont">
<div class="cn1" id="found">
<p><b>Quality 1 -</b> New Order / With Upload Instructions / DSA</p>
</div>
<div class="cn3">
<table>
<tr>
<td>Outstanding</td>
</tr>
<tr>
<td>Exceeds Expectations</td>
</tr>
<tr>
<td>Meets Expectations</td>
</tr>
<tr>
<td>Mostly Meets Expectations</td>
</tr>
<tr>
<td class="ark">Does not Meet Expectations</td>
</tr>
</table>
</div>
<div class="cn4">
<div class="cn5">
<table class="score">
<tr>
<td colspan="2">>= 99.6%</td>
</tr>
<tr>
<td>99.01%</td>
<td>99.59%</td>
</tr>
<tr>
<td>98.51%</td>
<td>99.00%</td>
</tr>
<tr>
<td>97.01%</td>
<td>98.50%</td>
</tr>
<tr>
<td class="ark" colspan="2"><= 97.00%</td>
</tr>
</table>
</div>
<div class="cn6">
<div class="hrw">
<p></p>
</div>
</div>
</div>
<div class="message">
<form name="fname" onsubmit="return validateForm()" method="post" action="insert.php">

<div class="num">
<input type="text" name="employee" id="employee" autocomplete="off" placeholder="Employee Id"><em id="info"></em>
<input type="text" class="rbm" name="production" autocomplete="off" id="parameters" onkeyup=myFunction();><em id="base"></em>
</div>
<div class="mark">
<input type="text" id="score" autocomplete="off" name="value1">
</div>
<div class="dis" id="description">
<input type="text" class="area" autocomplete="off" name="value2"><em id="base2"></em>
</div>
</div>
</div>
<div class="spc" id="blor">
<div class="msd">
<p>40%</p>
</div>
<div class="rrr">
</div>
</div>
<!--first set End-->
<!--second star-->
<div class="second">
<div class="cont">
<div class="cn1" id="found">
<p><b>Quality 2 -</b> Revisions / Without Upload Instructions / Bill Only</p>
</div>
<div class="cn3">
<table>
<tr>
<td>Outstanding</td>
</tr>
<tr>
<td>Exceeds Expectations</td>
</tr>
<tr>
<td>Meets Expectations</td>
</tr>
<tr>
<td>Mostly Meets Expectations</td>
</tr>
<tr>
<td class="ark">Does not Meet Expectations</td>
</tr>
</table>
</div>
<div class="cn4">
<div class="cn5">
<table class="score">
<tr>
<td colspan="2">100.00%</td>
</tr>
<tr>
<td>99.51%</td>
<td>99.99%</td>
</tr>
<tr>
<td>98.51%</td>
<td>99.50%</td>
</tr>
<tr>
<td>98.01%</td>
<td>98.50%</td>
</tr>
<tr>
<td class="ark" colspan="2"><= 98.00%</td>
</tr>
</table>
</div>
<div class="cn6">
<div class="hrw">
<p></p>
</div>
</div>
</div>
<div class="message">
<div class="num">
<input type="text" class="rbm" name="quality" autocomplete="off" id="ark" onkeyup=gama();><em id="base3"></em>
</div>
<div class="mark">
<input type="text" name="value3" autocomplete="off" id="ssm">
</div>
<div class="dis" id="max">
<input type="text" name="value4" autocomplete="off" class="area"><em id="base4"></em>
</div>
</div>
</div>
</div>
<div class="spc">
</div>
<!--end-->
<div class="second">
<div class="cont">
<div class="cn1" id="found">
<p><b>Productivity</b><br>
(standard calculation across all production service lines - 300 mins of effective time = 1 EPU (Equivalent Production Units). 
1.6 units or EPUs equate to 100% productivity
</b>
</p>
</div>
<div class="cn3">
<table>
<tr>
<td>Outstanding</td>
</tr>
<tr>
<td>Exceeds Expectations</td>
</tr>
<tr>
<td>Meets Expectations</td>
</tr>
<tr>
<td>Mostly Meets Expectations</td>
</tr>
<tr>
<td class="ark">Does not Meet Expectations</td>
</tr>
</table>
</div>
<div class="cn4">
<div class="cn5">
<table class="score">
<tr>
<td colspan="2">>= 1.52</td>
</tr>
<tr>
<td>1.42</td>
<td>1.51</td>
</tr>
<tr>
<td>1.25</td>
<td>1.41</td>
</tr>
<tr>
<td>1.11</td>
<td>1.24</td>
</tr>
<tr>
<td class="ark" colspan="2"><=1.10</td>
</tr>
</table>
</div>
<div class="cn6">
<div class="hrw">
<p>25%</p>
</div>
</div>
</div>
<div class="message">
<div class="num">
<input type="text" class="rbm" name="certification" autocomplete="off" id="before" onkeyup=sky();><em id="base5"></em>
</div>
<div class="mark">
<input type="text" name="value5" autocomplete="off" id="alpha">
</div>
<div class="dis" id="marks">
<input type="text" class="area" name="value6" autocomplete="off" >
</div>
</div>
</div>
</div>
<div class="spc">
</div>
<div class="cont">
<div class="cn1" id="ask">
<p><b>Campaign Management</b><br>
*Optimisation - Lines managed should meet their goal. Minimum of 500 lines per month or
 25 lines/day</p>
</div>
<div class="cn3">
<table>
<tr>
<td>Outstanding</td>
</tr>
<tr>
<td>Exceeds Expectations</td>
</tr>
<tr>
<td>Meets Expectations</td>
</tr>
<tr>
<td>Mostly Meets Expectations</td>
</tr>
<tr>
<td class="ark">Does not Meet Expectations</td>
</tr>
</table>
</div>
<div class="cn4">
<div class="cn5">
<table class="score">
<tr>
<td colspan="2">100%</td>
</tr>
<tr>
<td colspan="2">97.51% - 99.99%</td>
</tr>
<tr>
<td colspan="2">95.01% - 97.50%</td>
</tr>
<tr>
<td colspan="2">92.51% - 95.00%</td>
</tr>
<tr>
<td class="ark" colspan="2"> <92.50% </td>
</tr>
</table>
</div>
<div class="cn6">
<div class="hrw">
<p>5%</p>
</div>
</div>
</div>
<div class="message">
<div class="num">
<input type="text" class="rbm" name="training" autocomplete="off" id="ball" onkeyup=beta();><em id="base6"></em>
</div>
<div class="mark">
<input type="text" name="value7" id="king" autocomplete="off">

</div>
<div class="dis" id="mrc">
<input type = "text" class="area" name="value8" autocomplete="off">
</div>
</div>
</div>
<div class="spc">
</div>
<!--first set End-->
<!--second star-->
<div class="second">
<div class="cont">
<div class="cn1" id="ask" >
<p><b>Training & Certifications<br> - Skill Enhancement Trainings</b><br>
Self-initiative or seeking help on both personal and skill development aspects. 
Facilitated by 2adpro's training/L&D team 
Demonstrate results from the trainings / learning from the courses through the review period 
Assumption is that opportunities</p>
</div>
<div class="cn3">
<table>
<tr>
<td>Outstanding</td>
</tr>
<tr>
<td>Exceeds Expectations</td>
</tr>
<tr>
<td>Meets Expectations</td>
</tr>
<tr>
<td>Mostly Meets Expectations</td>
</tr>
<tr>
<td class="ark">Does not Meet Expectations</td>
</tr>
</table>
</div>
<div class="cn4">
<div class="cn5">
<table class="score">
<tr>
<td>>= 15</td>
</tr>
<tr>
<td>12 - 14</td>
</tr>
<tr>
<td>09 - 11</td>
</tr>
<tr>
<td>07 - 08</td>
</tr>
<tr>
<td class="ark"><= 6</td>
</tr>
</table>
</div>
<div class="cn6">
<div class="hrw">
<p>10%</p>
</div>
</div>
</div>
<div class="message">
<div class="num">
<input type="text" class="rbm" name="analysis" id="blank" autocomplete="off" onkeyup=ray();><em id="base7"></em>
</div>
<div class="mark">
<input type="text" name="value9" autocomplete="off" id="fit">
</div>
<div class="dis" id="shine">
<input type="text" class="area" autocomplete="off" name="value10">
</div>
</div>
</div>
</div>
<div class="spc">
</div>
<!--end-->
<div class="second">
<div class="cont">
<div class="cn1" id="ask">
<p><b>Projects & Initiatives - For Exec QCs, Snr and above<br>
Technical Presentations - For Junior and Exec Traffickers</b><br>
-1 per quarter expected as minimum (Meets/Does Not Meet)</p>
</div>
<div class="cn3">
<table>
<tr>
<td>Outstanding</td>
</tr>
<tr>
<td>Exceeds Expectations</td>
</tr>
<tr>
<td>Meets Expectations</td>
</tr>
<tr>
<td>Mostly Meets Expectations</td>
</tr>
<tr>
<td class="ark">Does not Meet Expectations</td>
</tr>
</table>
</div>
<div class="cn4">
<div class="cn5">
<table class="score">
<tr>
<td>4 projects</td>
</tr>
<tr>
<td>3 projects</td>
</tr>
<tr>
<td>2 projects</td>
</tr>
<tr>
<td>1 projects</td>
</tr>
<tr>
<td class="ark">> 0 projects</td>
</tr>
</table>
</div>
</div>
<div class="cn7">
<div class="alx">
<p>15</p>
</div>
</div>
</div>
<div class="message">
<div class="num">
<input type="text" class="rbm" autocomplete="off" name="attendance" id="rwb" onkeyup=micro();><em id="base8"></em>
</div>
<div class="mark">
<input type="text" autocomplete="off" name="value11" id="sibe">
</div>
<div class="dis" id="local">
<input type ="text" class="area" autocomplete="off" name="value12">
</div>
</div>
</div>
<div class="spc">
</div>
<!--end-->
<div class="second">
<div class="cont">
<div class="cn1" id="found">
<p><b>Unplanned Leaves</b><br>
(standard definition across organisation - Rostered days minus Attendance<br>
- Necessary justification provided to the Corporate Manager's for approval from tagging Unplanned Leaves in JDworkflow interface or removal of
any instances<br>
- Data auto populated during mid-year appraisal cycle<br>
- Staff and the reporting Leads responsibility to ensure workflow updates are done and is populating the current information each month</p>
</div>
<div class="cn3">
<table>
<tr>
<td>Outstanding</td>
</tr>
<tr>
<td>Exceeds Expectations</td>
</tr>
<tr>
<td>Meets Expectations</td>
</tr>
<tr>
<td>Mostly Meets Expectations</td>
</tr>
<tr>
<td class="ark">Does not Meet Expectations</td>
</tr>
</table>
</div>
<div class="cn4">
<div class="cn5">
<table class="score">
<tr>
<td>0 Instance</td>
</tr>
<tr>
<td>1 Instance</td>
</tr>
<tr>
<td>2 Instance</td>
</tr>
<tr>
<td>3 Instance</td>
</tr>
<tr>
<td class="ark">> 3 Instance</td>
</tr>
</table>
</div>
</div>
<div class="cn7">
<div class="alx">
<p>5</p>
</div>
</div>
</div>
<div class="message">
<div class="num">
<input type="text" class="rbm" autocomplete="off" name="leaves" id="ssw" onkeyup=nano();><em id="base9"></em>
</div>
<div class="mark">
<input type="text" autocomplete="off" name="value13" id="rim">
</div>
<div class="dis" id="alss">
<input type ="text" class="area" autocomplete="off" name="value14">
</div>
</div>
</div>
<div class="foot">
<div class="final">
<p> Total%<span class="dino"> 100%</span></p>
</div>
<div class="give">
<input type="submit" autocomplete="off" name="submit" value="SUBMIT" id="save">
</div>
</div>
</form>
</div>
</body>
</html>
