<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Client Lead KRA_2017-18</title>
<link rel="stylesheet" type="text/css" href="datastylesheet.css" />
<script src="source.js"></script>
<script src="valid.js"></script>
</head>
<body>
<div id="wrapper">
<div class="header">
<div class="qms">
<h3>Client Lead KRA_2017-18</h3>
</div>
<div class="apprisal">
<div class="para" id="fm">
<p>Parameters</p>
</div>
<div class="rating">
<p>Rating</p>
</div>
<div class="quality">
<div class="box1">
<p>Rating</p>
</div>
<div class="box2">
<div class="min">
<p>min</p>
</div>
<div class="max">
<p>max</p>
</div>
<div class="Weightage">
<p>Weightage</p>
</div>
</div>
</div>
</div>
<div class="spc">
<h5>Communication</h5>
</div>
<!--fist set start-->
<div class="cont">
<div class="cn1">
<p>Client Lead must provide reporting manager with at least 5 examples of effective customer relationship management for review per month. Can involve all communication channels available. Review will be based on<br>
- Understanding and effective issue definition<br>
- Effective solution based approach<br>
- Closure and follow up (should include evidence of actions taken outside the communication thread and show results<br>
- Accuracy of language in communications</p>
</div>
<div class="cn3">
<table>
<tr>
<td>Outstanding</td>
</tr>
<tr>
<td>Exceeds Expectations</td>
</tr>
<tr>
<td>Meets Expectations</td>
</tr>
<tr>
<td>Mostly Meets Expectations</td>
</tr>
<tr>
<td class="ark">Does not Meet Expectations</td>
</tr>
</table>
</div>
<div class="cn4">
<div class="cn5">
<table class="score">
<tr>
<td colspan="2">>94.00%</td>
</tr>
<tr>
<td>89.01%</td>
<td>94.00%</td>
</tr>
<tr>
<td>85.01%</td>
<td>89.00%</td>
</tr>
<tr>
<td>80.01%</td>
<td>85.00%</td>
</tr>
<tr>
<td class="ark" colspan="2">
Below 80 %</td>
</tr>
</table>
</div>
<div class="cn6">
<div class="hrw">
<p>30%</p>
</div>
</div>
</div>
<div class="message">
<form name="fname" onsubmit="return validateForm()" method="post" action="insert.php">

<div class="num">
<input type="text" name="employee" id="employee" autocomplete="off" placeholder="Employee Id"><em id="info"></em>
<input type="text" class="rbm" name="production" autocomplete="off" id="parameters" onkeyup=myFunction();><em id="base"></em>
</div>
<div class="mark">
<input type="text" id="score" autocomplete="off" name="value1">
</div>
<div class="dis" id="description">
<input type="text" class="area" autocomplete="off" name="value2"><em id="base2"></em>
</div>
</div>
</div>
<div class="spc">
<h5>Reporting</h5>
</div>
<!--first set End-->
<!--second star-->
<div class="second">
<div class="cont">
<div class="cn1">
<p>Reflects accuracy, timeliness and complexity of reporting undertaken. Includes internal reports if provided to an audience including managers<br>
- Demonstrates detailed understanding of all internal and external reports - purpose/objective, relationship, and impact on the clients end. Reports also includes Production<br>
- Involved in sending a report at an acceptable frequency to gauge this. There should not be repeated instances of issues identified or feedback given.<br>
- Accountable for accuracy of any/all reports both internal / external sent by self and direct reports. Measurement/lapse count will be based on instances identified by Manager and customer feedback<br>
- Strong understanding of productivity tools in MS Excel to generate and deliver reports on time or agreed timeframe with no delays.<br>
Measurement based on - • Accuracy and timeliness of data supplied • Intelligence & analysis<br>
- Able to summarise, provide insights and draw conclusions from the data collected</p>
</div>
<div class="cn3">
<table>
<tr>
<td>Outstanding</td>
</tr>
<tr>
<td>Exceeds Expectations</td>
</tr>
<tr>
<td>Meets Expectations</td>
</tr>
<tr>
<td>Mostly Meets Expectations</td>
</tr>
<tr>
<td class="ark">Does not Meet Expectations</td>
</tr>
</table>
</div>
<div class="cn4">
<div class="cn5">
<table class="score">
<tr>
<td colspan="2">>94.00</td>
</tr>
<tr>
<td>89.01%</td>
<td>94.00%</td>
</tr>
<tr>
<td>85.01%</td>
<td>89.00%</td>
</tr>
<tr>
<td>80.01%</td>
<td>85.00%</td>
</tr>
<tr>
<td class="ark" colspan="2">Below 80%</td>
</tr>
</table>
</div>
<div class="cn6">
<div class="hrw">
<p>20%</p>
</div>
</div>
</div>
<div class="message">
<div class="num">
<input type="text" class="rbm" name="quality" autocomplete="off" id="ark" onkeyup=gama();><em id="base3"></em>
</div>
<div class="mark">
<input type="text" name="value3" autocomplete="off" id="ssm">
</div>
<div class="dis" id="max">
<input type="text" name="value4" autocomplete="off" class="area"><em id="base4"></em>
</div>
</div>
</div>
</div>
<div class="spc">
<h5>People and performance management</h5>
</div>
<!--end-->
<div class="second">
<div class="cont">
<div class="cn1">
<p>- To own communication review process for at least one CSE. Provides weekly feedback and be able to show results in improved performance of the assigned individual(s)<br>
- ensure appropriate client support coverage for their teams - day-to-day capacity management, and ensuring direct reports develop the relevant skills to be cross functionally utilised<br>
- Leads by example in exhibiting an open and proactive approach to learning and self-development of skills</p>
</div>
<div class="cn3">
<table>
<tr>
<td>Outstanding</td>
</tr>
<tr>
<td>Exceeds Expectations</td>
</tr>
<tr>
<td>Meets Expectations</td>
</tr>
<tr>
<td>Mostly Meets Expectations</td>
</tr>
<tr>
<td class="ark">Does not Meet Expectations</td>
</tr>
</table>
</div>
<div class="cn4">
<div class="cn5">
<table class="score">
<tr>
<td><b>Met Expectation</b><br>
Evidence of monthly reviews, documented effort being made to develop next in line for the role with specific targets/goals to</td>
</tr>
<tr>
<td><b>Not Met</b><br>
No eveidence of monthly review and staff</td>
</tr>
</table>
</div>
<div class="cn6">
<div class="hrw">
<p>15%</p>
</div>
</div>
</div>
<div class="message">
<div class="num">
<input type="text" class="rbm" name="certification" autocomplete="off" id="before" onkeyup=sky();><em id="base5"></em>
</div>
<div class="mark">
<input type="text" name="value5" autocomplete="off" id="alpha">
</div>
<div class="dis" id="marks">
<input type="text" class="area" name="value6" autocomplete="off" >
</div>
</div>
</div>
</div>
<div class="spc">
<h5>Operational process improvement</h5>
</div>
<div class="cont">
<div class="cn1">
<p>Client Lead to undertake one process improvement project per quarter.<br>
- Project plan to be approved by reporting manager.<br>
 - Does not include tasks or projects assigned by manager.<br>
- esults to be documented and presented to Manager.</p>
</div>
<div class="cn3">
<table>
<tr>
<td>Outstanding</td>
</tr>
<tr>
<td>Exceeds Expectations</td>
</tr>
<tr>
<td>Meets Expectations</td>
</tr>
<tr>
<td>Mostly Meets Expectations</td>
</tr>
<tr>
<td class="ark">Does not Meet Expectations</td>
</tr>
</table>
</div>
<div class="cn4">
<div class="cn5">
<table class="score">
<tr>
<td>2 completed</td>
</tr>
<tr>
<td>3 Trainings completed</td>
</tr>
<tr>
<td>2 Trainings completed</td>
</tr>
<tr>
<td>1 Trainings completed</td>
</tr>
<tr>
<td class="ark">0 Not Done</td>
</tr>
</table>
</div>
<div class="cn6">
<div class="hrw">
<p>20%</p>
</div>
</div>
</div>
<div class="message">
<div class="num">
<input type="text" class="rbm" name="training" autocomplete="off" id="ball" onkeyup=beta();><em id="base6"></em>
</div>
<div class="mark">
<input type="text" name="value7" id="king" autocomplete="off">

</div>
<div class="dis" id="mrc">
<input type = "text" class="area" name="value8" autocomplete="off">
</div>
</div>
</div>
<div class="spc">
<h5>Domain and product expertise</h5>
</div>
<!--first set End-->
<!--second star-->
<div class="second">
<div class="cont">
<div class="cn1">
<p>- Demonstrates full understanding of the relevant workflows and JDX products (internal and client facing). Able to effectively train others and act as 1st line support and escalate effectively<br>
- Demonstrates full understanding of the nature of business (client and 2adpro) in assigned vertical. Able to effectively train and mentor others.<br>
- Demonstrates detailed understanding of the tools and processes available to ensure and enhance quality and productivity, and effectively promotes and ensures effective use on the floor</p>
</div>
<div class="cn3">
<table class="albe">
<tr>
<td>Outstanding</td>
</tr>
<tr>
<td>Meets Expectations</td>
</tr>
<tr>
<td class="ark">Does not Meet Expectations</td>
</tr>
</table>
</div>
<div class="cn4">
<div class="cn5">
<table class="score">
<tr>
<td>Can manage confidently and<br>
comfortably</td>
</tr>
<tr>
<td>Can manage to some degree,
but requires Customer
success/ manager direction</td>
</tr>
<tr>
<td>Not Managing</td>
</tr>
</table>
</div>
<div class="cn6">
<div class="hrw">
<p>15%</p>
</div>
</div>
</div>
<div class="message">
<div class="num">
<input type="text" class="rbm" name="analysis" id="blank" autocomplete="off" onkeyup=ray();><em id="base7"></em>
</div>
<div class="mark">
<input type="text" name="value9" autocomplete="off" id="fit">
</div>
<div class="dis" id="shine">
<input type="text" class="area" autocomplete="off" name="value10">
</div>
</div>
</div>
</div>
<!--end-->
</div>
<div class="foot">
<div class="final">
<p> Total%<span class="dino"> 100%</span></p>
</div>
<div class="give">
<input type="submit" autocomplete="off" name="submit" value="SUBMIT" id="save">
</div>
</div>
</div>
</body>
</html>
