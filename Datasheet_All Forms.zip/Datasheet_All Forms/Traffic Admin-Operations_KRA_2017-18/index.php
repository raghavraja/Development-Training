<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Traffic Admin-Operations_KRA_2017-18</title>
<link rel="stylesheet" type="text/css" href="datastylesheet.css" />
<script src="source.js"></script>
<script src="valid.js"></script>
</head>
<body>
<div id="wrapper">
<div class="header">
<div class="para2">
<p><b>Traffic Admin-Operations</b></p>
</div>
<div class="apprisal">
<div class="para">
<p>KRA/KPI</p>
</div>
<div class="quality">
<div class="box2">
<div class="min">
<p>DNME</p>
</div>
<div class="max">
<p>MME</p>
</div>
<div class="max">
<p>ME</p>
</div>
<div class="max">
<p>EE</p>
</div>
<div class="max">
<p>CO</p>
</div>
</div>
</div>
<div class="Weightage">
<p>Weightage</p>
</div>
</div>
<div class="snip">
<p><b>Monitoring JAS & Workflow</b></p>
</div>
<div class="max">
<p>> 6 instances</p>
</div>
<div class="max">
<p>5 to 6 instances </p>
</div><div class="max">
<p>3 to 4 instances </p>
</div>
<div class="max">
<p>1 to 2 instances</p>
</div>
<div class="max">
<p>0 instance </p>
</div>
<!--fist set start-->
<div class="cont">
<div class="cn1">
<p>- Monitoring JAS every 15 mins and manually push jobs to workflow which are above 20MB (failed orders). Number of failure flagged by Ops/Implementation/JD Support teams. Individual allocation of instances will be tracked by the reporting Lead/Manager					
- Immediately address orders stuck in Shipment queue (> 15 mins). Reinitiate orders as a required action and inform stakeholders. Instances reported by Ops/JD support/Implementation team. Tracked by reporting Lead/Manager.										
</p>
</div>
<div class="gain">
<p>50%</p>
</div>

<div class="message">
<form name="fname" onsubmit="return validateForm()" method="post" action="insert.php">

<div class="num">
<input type="text" name="employee" id="employee" autocomplete="off" placeholder="Employee Id"><em id="info"></em>
<input type="text" class="rbm" name="production" autocomplete="off" id="parameters" onkeyup=myFunction();><em id="base"></em>
</div>
<div class="mark">
<input type="text" id="score" autocomplete="off" name="value1">
</div>
<div class="dis" id="description">
<input type="text" class="area" autocomplete="off" name="value2"><em id="base2"></em>
</div>
</div>
</div>
<div class="spc">
</div>
<!--first set End-->
<!--second star-->
<div class="snip">
<p><b>Trainings and Certifications</b></p>
</div>
<div class="max">
<p>2 Certifications</p>
</div>
<div class="max">
<p>4 Certifications</p>
</div>
<div class="max">
<p>8 Certifications</p>
</div><div class="max">
<p>10 Certifications</p>
</div>
<div class="max">
<p>12 Certifications</p>
</div>
<!--fist set start-->
<div class="cont">
<div class="cn1">
<p>- Completes all scheduled training on time. Certifications without any hiccups.<br>				
- Demonstrates effective understanding and implementation of tools on the floor.<br>					
- Usage of tools and techniques as required in their next logical role<br> 					
- Learn and able to understand all aspects of production by the end of the review period and able to demonstrate.<br> 					
- Evolves through self learning and ability to contribute towards the process improvement initiatives on the floor.<br>					
- Willingness to learn and take up training and certification as needed for their career/ next logical role<br>					
</p>
</div>
<div class="gain">
<p>20%</p>
</div>
<div class="message">
<div class="num">
<input type="text" class="rbm" name="quality" autocomplete="off" id="ark" onkeyup=gama();><em id="base3"></em>
</div>
<div class="mark">
<input type="text" name="value3" autocomplete="off" id="ssm">
</div>
<div class="dis" id="max">
<input type="text" name="value4" autocomplete="off" class="area"><em id="base4"></em>
</div>
</div>
</div>
</div>
<div class="spc">
</div>
<!--end-->
<div class="snip">
<p><b>Billing/exception billing verification accuracy</b></p>
</div>
<div class="max">
<p>> 6 instances</p>
</div>
<div class="max">
<p>5 to 6 instances </p>
</div>
<div class="max">
<p>3 to 4 instances </p>
</div><div class="max">
<p>1 to 2 instances</p>
</div>
<div class="max">
<p>0 instance</p>
</div>
<!--fist set start-->
<div class="cont">
<div class="cn1">
<p>- Accountable for accuracy of any/all reports both internal sent by self.
Measurement/lapse count will be based on instances identified by Manager and customer feedback</p>
</div>
<div class="gain">
<p>10%</p>
</div>
<!--fist set start-->

<div class="message">
<div class="num">
<input type="text" class="rbm" name="certification" autocomplete="off" id="before" onkeyup=sky();><em id="base5"></em>
</div>
<div class="mark">
<input type="text" name="value5" autocomplete="off" id="alpha">
</div>
<div class="dis" id="marks">
<input type="text" class="area" name="value6" autocomplete="off" >
</div>
</div>
</div>
<div class="spc">
</div>
<div class="snip">
<p><b>Attendance</b></p>
</div>
<div class="max">
<p>> 3 days</p>
</div>
<div class="max">
<p>3 days</p>
</div>
<div class="max">
<p>2 days</p>
</div><div class="max">
<p>1 day</p>
</div>
<div class="max">
<p>0 days</p>
</div>
<div class="cont">
<div class="cn1">
<p>* Un Planned Leave<br>
1. Any instance of uninformed leaves or LOP<br>
2. Leaves applied outside of advance notice mentioned in the leave policy <br>
3. Unable to come back on the said days after planned leave <br>
4. Extension to planned leaves <br>
5. Calling out last minute or a day before scheduled shift<br> 
6. Sick leave without doctors certificate <br>
					
</p>
</div>
<div class="gain">
<p>20%</p>
</div>
<!--fist set start-->

<div class="message">
<div class="num">
<input type="text" class="rbm" name="training" autocomplete="off" id="ball" onkeyup=beta();><em id="base6"></em>
</div>
<div class="mark">
<input type="text" name="value7" id="king" autocomplete="off">
</div>
<div class="dis" id="mrc">
<input type = "text" class="area" name="value8" autocomplete="off">
</div>
</div>
</div>
<!--FOOTR------>
<div class="foot">
<div class="final">
<p> Total%<span class="dino"> 100%</span></p>
</div>
<div class="give">
<input type="submit" autocomplete="off" name="submit" value="SUBMIT" id="save">
</div>
</div>
</div>
</body>
</html>
