<!DCTYPE html>
<html>
<head>
<title>Client Manager</title>
<link rel="stylesheet" type="text/css" href="stylesheet.css">
</head>
<body>
<div id="wrapper">
<div class="header">
<div class="kpi">
<h1>KPI & KRA for Client Manager - 2017-18</h1>
</div>
<table>
<tr> 
<th  class="b1">KRAs</th>
<th class="b2">KPIs</th>
<th class="m2">KPIs</th>
<th class="m2">KPIs</th>
<th class="m2">KPIs</th>
<th class="m2">KPIs</th>
<th class="m2">KPIs</th>
<th class="m2">KPIs</th>
</tr>
</table>
<div class="kra">
<h5>SLA and Operational Metrics</h5>
</div>
<div class="box1">
<table class="max">
<tr>
<td class="b3"><b>Improvement to the Service Level Agreement (Quality)</b><br>
- Targeted at specific improvements shown over the last FY closing number for the corporate during<br>
 the current review period. Corporate must be meeting the minimum expected SLA to qualify for this<br>
 KRA categories<br>
- Standard 2adpro contractual definition applies for computation. Includes all contractual Product/service offerings to the customer/corporate<br>
- In case of geographic split and availability of location manager, the performance will be limited to the site/location and based on the available opportunity<br>
- Provide necessary support and direction to Leads/team to achieve this<br>
- Challenges identified are documented, evidenced and resolved with the HOD or Customer<br>
- Substantiated with a minimum of 10% Average Outgoing Quality sampling (stricter quality audits)<br>
taking into consideration all aspects that impact true quality. In case SLA quality is already above 98%, then consider improvement to AOQ quality<br>
- Assumption is that all/most of the teams will organically grow or maintain the current/historic performance levels</td>
<td class="x1">< = 0%</td>
<td class="x1">< = 0%</td>
<td class="x1">< = 0%</td>
<td class="x1">< = 0%</td>
<td class="x1">< = 0%</td>
<td class="x1">< = 0%</td>
</tr>
<tr>
<td class="b3"><b>Improvement to the Service Level Agreement (On Time Delivery)</b>
- Targeted at specific improvements shown over the last FY closing number for the corporate during the current review period. Corporate must be meeting the minimum expected SLA to qualify for this KRA categories
- Standard 2adpro contractual definition applies for computation. Includes all contractual Product/service offerings to the customer/corporate, and all touches
- In case of geographic split and availability of location manager, the performance will be limited to the site/location and based on the available opportunity
- Provide necessary support and direction to Leads/team to achieve this
- Challenges identified are documented, evidenced and resolved with the HOD or Customer
 Assumption is that all/most of the teams will organically grow or maintain the current/historic performance levels</td>
<td class="x1">< = 0%</td>
<td class="x1">< = 0%</td>
<td class="x1">< = 0%</td>
<td class="x1">< = 0%</td>
<td class="x1">< = 0%</td>
<td class="x1">< = 0%</td>
</tr>
<tr>
<td class="b3">Productivity improvement (baseline from the previous FY closing number)
Assumption here is that the Manager has already made an effort in the past to meet the target productivity for the corporate</td>
<td class="x1">< = 0%</td>
<td class="x1">< = 0%</td>
<td class="x1">< = 0%</td>
<td class="x1">< = 0%</td>
<td class="x1">< = 0%</td>
<td class="x1">< = 0%</td>
</tr>
<tr>
<td class="b3">Productivity improvement (baseline from the previous FY closing number)
Assumption here is that the Manager has already made an effort in the past to meet the target productivity for the corporate</td>
<td class="x1">< = 0%</td>
<td class="x1">< = 0%</td>
<td class="x1">< = 0%</td>
<td class="x1">< = 0%</td>
<td class="x1">< = 0%</td>
<td class="x1">< = 0%</td>
</tr>
</table>
</div>
<div class="box2">
<h3>Reporting & Documentation</h3>
</div>
<div class="box1">
<table class="max">
<tr>
<td class="b3">Productivity improvement (baseline from the previous FY closing number)
Assumption here is that the Manager has already made an effort in the past to meet the target productivity for the corporate</td>
<td class="x1">< = 0%</td>
<td class="x1">< = 0%</td>
<td class="x1">< = 0%</td>
<td class="x1">< = 0%</td>
<td class="x1">< = 0%</td>
<td class="x1">< = 0%</td>
</tr>
<tr>
<td class="b3">Productivity improvement (baseline from the previous FY closing number)
Assumption here is that the Manager has already made an effort in the past to meet the target productivity for the corporate</td>
<td class="x1">< = 0%</td>
<td class="x1">< = 0%</td>
<td class="x1">< = 0%</td>
<td class="x1">< = 0%</td>
<td class="x1">< = 0%</td>
<td class="x1">< = 0%</td>
</tr>
</table>
</div>
<div class="mask">
<h5>Operational Support</h5>
</div>
<div class="box1">
<table class="max">
<td class="b3"><b>SOP, Client Handbook and other documentation</b><br>
- Ensures these document are unified and kept up to date real time by self or nominated staff<br>
- Owns the document in its entirety<br>
- All exceptions/agreements to the process are effectively documented and communicated<br>
- Seeks and documents sign-off from the customer on a periodic/regular basis (when there is an update)<br>
- Ensures understanding is shared and effectiveness / adherence is measured on a periodic basis with the team.
</td>
<td class="x1">< = 0%</td>
<td class="x1">< = 0%</td>
<td class="x1">< = 0%</td>
<td class="x1">< = 0%</td>
<td class="x1">< = 0%</td>
<td class="x1">< = 0%</td>
</tr>
<tr>
<td class="b3"><b>Timely and Effective Response/Escalation Management</b> 
- Ensure expectations from the organization are communicated to the team <br>
- Ensure commitments made to customers (internal / external) are  followed up with action and resolution.<br>
- Takes a process approach towards resolution of issues which is repeatable, effective and scalable
</td>
<td class="x1">< = 0%</td>
<td class="x1">< = 0%</td>
<td class="x1">< = 0%</td>
<td class="x1">< = 0%</td>
<td class="x1">< = 0%</td>
<td class="x1">< = 0%</td>
</tr>
<tr>
<td class="b3">Productivity improvement (baseline from the previous FY closing number)
Assumption here is that the Manager has already made an effort in the past to meet the target productivity for the corporate</td>
<td class="x1">< = 0%</td>
<td class="x1">< = 0%</td>
<td class="x1">< = 0%</td>
<td class="x1">< = 0%</td>
<td class="x1">< = 0%</td>
<td class="x1">< = 0%</td>
</tr>
</table>
</div>
<div class="box2">
<h3>Reporting & Documentation</h3>
</div>
<div class="box1">
<table class="max">
<tr>
<td class="b3">Productivity improvement (baseline from the previous FY closing number)
Assumption here is that the Manager has already made an effort in the past to meet the target productivity for the corporate</td>
<td class="x1">< = 0%</td>
<td class="x1">< = 0%</td>
<td class="x1">< = 0%</td>
<td class="x1">< = 0%</td>
<td class="x1">< = 0%</td>
<td class="x1">< = 0%</td>
</tr>
<tr>
<td class="b3">Productivity improvement (baseline from the previous FY closing number)
Assumption here is that the Manager has already made an effort in the past to meet the target productivity for the corporate</td>
<td class="x1">< = 0%</td>
<td class="x1">< = 0%</td>
<td class="x1">< = 0%</td>
<td class="x1">< = 0%</td>
<td class="x1">< = 0%</td>
<td class="x1">< = 0%</td>
</tr>
</table>
</div>
<div class="mask">
<h5>Operational Support</h5>
</div>
<div class="box1">
<table class="max">
<td class="b3"><b>SOP, Client Handbook and other documentation</b><br>
- Ensures these document are unified and kept up to date real time by self or nominated staff<br>
- Owns the document in its entirety<br>
- All exceptions/agreements to the process are effectively documented and communicated<br>
- Seeks and documents sign-off from the customer on a periodic/regular basis (when there is an update)<br>
- Ensures understanding is shared and effectiveness / adherence is measured on a periodic basis with the team.
</td>
<td class="x1">< = 0%</td>
<td class="x1">< = 0%</td>
<td class="x1">< = 0%</td>
<td class="x1">< = 0%</td>
<td class="x1">< = 0%</td>
<td class="x1">< = 0%</td>
</tr>
<tr>
<td class="b3"><b>Timely and Effective Response/Escalation Management</b> 
- Ensure expectations from the organization are communicated to the team <br>
- Ensure commitments made to customers (internal / external) are  followed up with action and resolution.<br>
- Takes a process approach towards resolution of issues which is repeatable, effective and scalable
</td>
<td class="x1">< = 0%</td>
<td class="x1">< = 0%</td>
<td class="x1">< = 0%</td>
<td class="x1">< = 0%</td>
<td class="x1">< = 0%</td>
<td class="x1">< = 0%</td>
</tr>
<tr>
<td class="b3">Productivity improvement (baseline from the previous FY closing number)
Assumption here is that the Manager has already made an effort in the past to meet the target productivity for the corporate</td>
<td class="x1">< = 0%</td>
<td class="x1">< = 0%</td>
<td class="x1">< = 0%</td>
<td class="x1">< = 0%</td>
<td class="x1">< = 0%</td>
<td class="x1">< = 0%</td>
</tr>
</table>
</div>
<div class="uk">
<div class="message" id="sl1">
<form name="fname" onsubmit="return validateForm()" method="post" action="insert.php">

<div class="num">
<input type="text" name="employee" id="employee" autocomplete="off" placeholder="Employee Id"><em id="info"></em>
<input type="text" class="rbm" name="production" autocomplete="off" id="parameters" onkeyup=myFunction();><em id="base"></em>
</div>
<div class="mark">
<input type="text" id="score" autocomplete="off" name="value1">
</div>
<div class="dis" id="description">
<input type="text" class="area" autocomplete="off" name="value2"><em id="base2"></em>
</div>
</div>
<div class="message" id="sl2">
<div class="num">
<input type="text" class="rbm" name="quality" autocomplete="off" id="ark" onkeyup=gama();><em id="base3"></em>
</div>
<div class="mark">
<input type="text" name="value3" autocomplete="off" id="ssm">
</div>
<div class="dis" id="max">
<input type="text" name="value4" autocomplete="off" class="area"><em id="base4"></em>
</div>
</div>
<div class="message" id="sl3">
<div class="num">
<input type="text" class="rbm" name="certification" autocomplete="off" id="before" onkeyup=sky();><em id="base5"></em>
</div>
<div class="mark">
<input type="text" name="value5" autocomplete="off" id="alpha">
</div>
<div class="dis" id="marks">
<input type="text" class="area" name="value6" autocomplete="off" >
</div>
</div>
<div class="message" id="sl4">
<div class="num">
<input type="text" class="rbm" name="training" autocomplete="off" id="ball" onkeyup=beta();><em id="base6"></em>
</div>
<div class="mark">
<input type="text" name="value7" id="king" autocomplete="off">

</div>
<div class="dis" id="mrc">
<input type = "text" class="area" name="value8" autocomplete="off">
</div>
</div>
<div class="message" id="sl5">
<div class="num">
<input type="text" class="rbm" name="analysis" id="blank" autocomplete="off" onkeyup=ray();><em id="base7"></em>
</div>
<div class="mark">
<input type="text" name="value9" autocomplete="off" id="fit">
</div>
<div class="dis" id="shine">
<input type="text" class="area" autocomplete="off" name="value10">
</div>
</div>
<div class="message" id="sl6">
<div class="num">
<input type="text" class="rbm" autocomplete="off" name="attendance" id="rwb" onkeyup=micro();><em id="base8"></em>
</div>
<div class="mark">
<input type="text" autocomplete="off" name="value11" id="sibe">
</div>
<div class="dis" id="local">
<input type ="text" class="area" autocomplete="off" name="value12">
</div>
</div>
<div class="message" id="sl7">
<div class="num">
<input type="text" class="rbm" autocomplete="off" name="attendance" id="rwb" onkeyup=micro();><em id="base8"></em>
</div>
<div class="mark">
<input type="text" autocomplete="off" name="value11" id="sibe">
</div>
<div class="dis" id="local">
<input type ="text" class="area" autocomplete="off" name="value12">
</div>
</div>
<div class="message" id="sl8">
<div class="num">
<input type="text" class="rbm" autocomplete="off" name="attendance" id="rwb" onkeyup=micro();><em id="base8"></em>
</div>
<div class="mark">
<input type="text" autocomplete="off" name="value11" id="sibe">
</div>
<div class="dis" id="local">
<input type ="text" class="area" autocomplete="off" name="value12">
</div>
</div>
<div class="message" id="sl9">
<div class="num">
<input type="text" class="rbm" autocomplete="off" name="attendance" id="rwb" onkeyup=micro();><em id="base8"></em>
</div>
<div class="mark">
<input type="text" autocomplete="off" name="value11" id="sibe">
</div>
<div class="dis" id="local">
<input type ="text" class="area" autocomplete="off" name="value12">
</div>
</div>
<div class="message" id="sl10">
<div class="num">
<input type="text" class="rbm" autocomplete="off" name="attendance" id="rwb" onkeyup=micro();><em id="base8"></em>
</div>
<div class="mark">
<input type="text" autocomplete="off" name="value11" id="sibe">
</div>
<div class="dis" id="local">
<input type ="text" class="area" autocomplete="off" name="value12">
</div>
</div>
<div class="message" id="sl11">
<div class="num">
<input type="text" class="rbm" autocomplete="off" name="attendance" id="rwb" onkeyup=micro();><em id="base8"></em>
</div>
<div class="mark">
<input type="text" autocomplete="off" name="value11" id="sibe">
</div>
<div class="dis" id="local">
<input type ="text" class="area" autocomplete="off" name="value12">
</div>
</div>
<div class="message" id="sl12">
<div class="num">
<input type="text" class="rbm" autocomplete="off" name="attendance" id="rwb" onkeyup=micro();><em id="base8"></em>
</div>
<div class="mark">
<input type="text" autocomplete="off" name="value11" id="sibe">
</div>
<div class="dis" id="local">
<input type ="text" class="area" autocomplete="off" name="value12">
</div>
</div>
<div class="message" id="sl13">
<div class="num">
<input type="text" class="rbm" autocomplete="off" name="attendance" id="rwb" onkeyup=micro();><em id="base8"></em>
</div>
<div class="mark">
<input type="text" autocomplete="off" name="value11" id="sibe">
</div>
<div class="dis" id="local">
<input type ="text" class="area" autocomplete="off" name="value12">
</div>
</div>
<div class="message" id="sl14">
<div class="num">
<input type="text" class="rbm" autocomplete="off" name="attendance" id="rwb" onkeyup=micro();><em id="base8"></em>
</div>
<div class="mark">
<input type="text" autocomplete="off" name="value11" id="sibe">
</div>
<div class="dis" id="local">
<input type ="text" class="area" autocomplete="off" name="value12">
</div>
</div>
</div>
<div class="foot">
<div class="final">
<p> Total%<span class="dino"> 100%</span></p>
</div>
<div class="give">
<input type="submit" autocomplete="off" name="submit" value="SUBMIT" id="save">
</div>
</div>
</div>
</body>
</html>