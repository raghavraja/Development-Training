function myFunction()
{
	var name = document.getElementById("parameters");
	var strike = name.value;
	
	if(strike <= 96)
	{
		document.getElementById("score").value="Does not Meet Expectations";
		document.getElementById("description").style.display = "none";
	}
	
	else if (strike <= 97.75)
	{
		document.getElementById("score").value="Mostly Meets Expectations";
		document.getElementById("description").style.display = "none";
	}
	
	else if (strike <= 98.75)
		
		{
			document.getElementById("score").value="Meets Expectations";
			document.getElementById("description").style.display = "none";
		}
	
	else if (strike  <= 99.50)
		
		{
			document.getElementById("score").value="Exceeds Expectations";
			document.getElementById("description").style.display = "block";
		}
		
	else if (strike > 99.51)
        
		{
			document.getElementById("score").value="Outstanding";
			document.getElementById("description").style.display = "block";
		}			
	
	else
	{
		document.getElementById("score").value="";
	}
		
}

/*first set end */

		
/* second set end */
function gama()
{
var a = document.getElementById("ark");
var b = a.value;

if(b <= 16.50)
{
document.getElementById("ssm").value="Does not Meet Expectations";
document.getElementById("max").style.display = "none";

}

else if( b <= 18)
{
document.getElementById("ssm").value="Mostly Meets Expectations"
document.getElementById("max").style.display = "none";
}

else if( b <= 19)
{
document.getElementById("ssm").value="Mostly Meets Expectations"
document.getElementById("max").style.display = "none";
}

else if (b <= 20.50)
{
document.getElementById("ssm").value="Exceeds Expectations"
document.getElementById("max").style.display = "block";

}
else if (b >20.51)
{
document.getElementById("ssm").value="Outstanding"
document.getElementById("max").style.display = "block";

}

else

{
document.getElementById("ssm").value="";
document.getElementById("max").style.display = "none";

}


}

/* third set start */
function sky()
{
var a = document.getElementById("before");
var b = a.value;

if(b >=3)
{
document.getElementById("alpha").value="Does not Meet Expectations";
document.getElementById("marks").style.display = "none";

}

else if( b == 3)
{
document.getElementById("alpha").value="Mostly Meets Expectations"
document.getElementById("marks").style.display = "none";
}

else if (b == 1)
{
document.getElementById("alpha").value="Meets Expectations"
document.getElementById("marks").style.display = "none";

}
else if (b == 1)
{
document.getElementById("alpha").value="Exceeds Expectations"
document.getElementById("marks").style.display = "block";

}

else if (b  == 0)
{
document.getElementById("alpha").value="Outstanding"
document.getElementById("marks").style.display = "block";

}

else

{
document.getElementById("alpha").value="";
document.getElementById("marks").style.display = "none";

}


}
/* third set end */
/* fourth set star */
