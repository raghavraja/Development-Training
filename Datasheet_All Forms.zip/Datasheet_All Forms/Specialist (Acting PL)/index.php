<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Data</title>
<link rel="stylesheet" type="text/css" href="datastylesheet.css" />
<script src="source.js"></script>
<script src="valid.js"></script>
</head>
<body>
<div id="wrapper">
<div class="header">
<div class="apprisal">
<div class="para">
<p>Acting Planning Lead 'Specialist' KRA/KPI - 2017-18</p>
</div>
<div class="quality">
<div class="rare">
<p>Rating</p>
</div>
<div class="box2">
<div class="min">
<p>DNME</p>
</div>
<div class="max">
<p>MME</p>
</div>
<div class="max">
<p>ME</p>
</div>
<div class="max">
<p>EE</p>
</div>
<div class="max">
<p>CO</p>
</div>
</div>
</div>
<div class="Weightage">
<p>Weightage</p>
</div>
</div>
<div class="snip">
<p><b>Quality Improvement</b></p>
</div>
<div class="max">
<p>< = 0%</p>
</div>
<div class="max">
<p>0.5% - 0.9%</p>
</div>
<div class="max">
<p>0.91% - 1.5%</p>
</div><div class="max">
<p>1.51 - 3.00%</p>
</div>
<div class="max">
<p>> = 3.01%</p>
</div>
<!--fist set start-->
<div class="cont">
<div class="cn1">
<p>- Measured based on increase/decrease in quality from the last review periods (2016-17) closing quality for the account/corporate(s)					
- Drive continuous improvement culture on the floor					
- Documentation/quantification of the improvement initiative that has helped improve quality is mandatory. Improvements made should be sustainable and controls defined. FIF should show improvement i.e. reduction quarter on quarter					
- A minimum of 5% AOQ sampling by shift is compulsory through out the review period (online or offline)					
- In case corporate is already reporting higher external quality, reporting Manager to engage independent party for stricter AOQ sampling month on month and that becomes the quality performance of the individual					
- In case of multiple Planning Leads in a corporate, ownership can be shared or singled. Managers approval will be required					
- Drive process adherence or look at automated solution for process adherence leading to quality improvement					
</p>
</div>
<div class="gain">
<p>35%</p>
</div>

<div class="message">
<form name="fname" onsubmit="return validateForm()" method="post" action="insert.php">

<div class="num">
<input type="text" name="employee" id="employee" autocomplete="off" placeholder="Employee Id"><em id="info"></em>
<input type="text" class="rbm" name="production" autocomplete="off" id="parameters" onkeyup=myFunction();><em id="base"></em>
</div>
<div class="mark">
<input type="text" id="score" autocomplete="off" name="value1">
</div>
<div class="dis" id="description">
<input type="text" class="area" autocomplete="off" name="value2"><em id="base2"></em>
</div>
</div>
</div>
<div class="spc">
</div>
<!--first set End-->
<!--second star-->
<div class="snip">
<p><b>On Time Delivery Improvement</b></p>
</div>
<div class="max">
<p>< = 0%</p>
</div>
<div class="max">
<p>0.5% - 0.9%</p>
</div>
<div class="max">
<p>0.91% - 1.5%</p>
</div><div class="max">
<p>1.51 - 3.00%</p>
</div>
<div class="max">
<p>> = 3.01%</p>
</div>
<!--fist set start-->
<div class="cont">
<div class="cn1">
<p>- Measured based on increase/decrease in OTD performance from the last review periods (2016-17) closing OTD for the account/corporate					
- Look at possible automation/auto assign of most/all work through the workflow system to improve quality - alignment to the customers prioritisation requirement and 2adpro's SLA agreement					
- Total touches (Rush, Revisions, and Overnight) will be primarily considered along with tasks, project and/or timeliness of email responses as secondary means for measuring this KRA/KPI.					
- Documentation/quantification of the improvement initiative that has helped improve OTD is mandatory. Improvements made should be sustainable and controls defined to ensure FIF shows 'considerable' decline quarter on quarter					
- In case of multiple Planning Leads in a corporate, ownership can be shared or singled. Managers approval will be required								</p>
</div>
<div class="gain">
<p>20%</p>
</div>
<div class="message">
<div class="num">
<input type="text" class="rbm" name="quality" autocomplete="off" id="ark" onkeyup=gama();><em id="base3"></em>
</div>
<div class="mark">
<input type="text" name="value3" autocomplete="off" id="ssm">
</div>
<div class="dis" id="max">
<input type="text" name="value4" autocomplete="off" class="area"><em id="base4"></em>
</div>
</div>
</div>
</div>
<div class="spc">
</div>
<!--end-->
<div class="snip">
<p><b>Shift/Monthly Utilization (annulised number)</b></p>
</div>
<div class="max">
<p>< 60%</p>
</div>
<div class="max">
<p>60% - 74.9%</p>
</div>
<div class="max">
<p>75.0% - 80.0%</p>
</div><div class="max">
<p>80.1% - 85.0%</p>
</div>
<div class="max">
<p>> 85.0%</p>
</div>
<!--fist set start-->
<div class="cont">
<div class="cn1">
<p>- Self tracking and publishing with minimum to no supervision from the reporting Manager.<br>					
- Data shows continuous improvement. (excludes volumes at specific lean period and ramp up stabilization).<br>					
- Appropriate decision of lending resources to improve utilization.  Wider view point (within service lines, outside service line). Finding opportunities for up skilling and lending<br>					
- Identification of excess/deficit staffing on a regular basis and reporting to Manager. Volume trend analysis basis historic volumes/trends<br>					
- Ensure shifts are 'rightly' staffed to delivery as per clients expectations and SLAs.<br>
- Effective management of leaves (planned / unplanned)					
					
</p>
</div>
<div class="gain">
<p>20%</p>
</div>
<!--fist set start-->

<div class="message">
<div class="num">
<input type="text" class="rbm" name="certification" autocomplete="off" id="before" onkeyup=sky();><em id="base5"></em>
</div>
<div class="mark">
<input type="text" name="value5" autocomplete="off" id="alpha">
</div>
<div class="dis" id="marks">
<input type="text" class="area" name="value6" autocomplete="off" >
</div>
</div>
</div>
<div class="spc">
</div>
<div class="snip">
<p><b>Attendance Management</b></p>
</div>
<div class="max">
<p>>=10%</p>
</div>
<div class="max">
<p>7%-9.9%</p>
</div>
<div class="max">
<p>5%</p>
</div><div class="max">
<p>2%</p>
</div>
<div class="max">
<p><2%</p>
</div>
<div class="cont">
<div class="cn1">
<p>- Self tracking and publishing with minimum to no supervision from the reporting Manager.<br>					
- Data shows continuous improvement. (excludes volumes at specific lean period and ramp up stabilization).<br>					
- Appropriate decision of lending resources to improve utilization.  Wider view point (within service lines, outside service line). Finding opportunities for up skilling and lending<br>					
- Identification of excess/deficit staffing on a regular basis and reporting to Manager. Volume trend analysis basis historic volumes/trends<br>					
- Ensure shifts are 'rightly' staffed to delivery as per clients expectations and SLAs.<br>
- Effective management of leaves (planned / unplanned)					
					
</p>
</div>
<div class="gain">
<p>20%</p>
</div>
<!--fist set start-->

<div class="message">
<div class="num">
<input type="text" class="rbm" name="training" autocomplete="off" id="ball" onkeyup=beta();><em id="base6"></em>
</div>
<div class="mark">
<input type="text" name="value7" id="king" autocomplete="off">

</div>
<div class="dis" id="mrc">
<input type = "text" class="area" name="value8" autocomplete="off">
</div>
</div>
</div>
<div class="spc">
</div>
<!--first set End-->
<!--second star-->
<div class="snip">
<p><b>Team's Productivity</b></p>
</div>
<div class="max">
<p>- 1 ad/person</p>
</div>
<div class="max">
<p>Same / no</p>
</div>
<div class="max">
<p>+ 2 ads/person</p>
</div><div class="max">
<p>+ 3 ads/person</p>
</div>
<div class="max">
<p>+ 4 ads/person</p>
</div>
<!--fist set start-->
<div class="cont">
<div class="cn1">
<p>Management of unplanned leaves on his/her shift.</p>
</div>
<div class="gain">
<p>15%</p>
</div>
<div class="message">
<div class="num">
<input type="text" class="rbm" name="analysis" id="blank" autocomplete="off" onkeyup=ray();><em id="base7"></em>
</div>
<div class="mark">
<input type="text" name="value9" autocomplete="off" id="fit">
</div>
<div class="dis" id="shine">
<input type="text" class="area" autocomplete="off" name="value10">
</div>
</div>
</div>
</div>
<div class="spc">
</div>
<!--end-->
<div class="snip">
<p><b>Process Adherence (Reporting Managers to audit )</b></p>
</div>
<div class="max">
<p>> 8 lapses</p>
</div>
<div class="max">
<p>5-7 lapses</p>
</div>
<div class="max">
<p>3-4 lapses</p>
</div><div class="max">
<p>1-2 lapses</p>
</div>
<div class="max">
<p>0 lapses</p>
</div>
<!--fist set start-->
<div class="cont">
<div class="cn1">
<p>- Projects identified and undertaken for overall productivity improvement of the team<br>					
- Phase wise productivity tracking of new joinees<br>					
- Compliance check calibration exercises for the team<br>					
- Identification of client-wise/publisher-wise/account wise challenges, documenting and sharing it with the CM/OM on a regular basis to be taken up with the client<br>				
- Identify process challenges / bottlenecks and suggest/implement change for productivity/TAT improvement</p>
</div>
<div class="gain">
<p>5%</p>
</div>
<div class="message">
<div class="num">
<input type="text" class="rbm" autocomplete="off" name="attendance" id="rwb" onkeyup=micro();><em id="base8"></em>
</div>
<div class="mark">
<input type="text" autocomplete="off" name="value11" id="sibe">
</div>
<div class="dis" id="local">
<input type ="text" class="area" autocomplete="off" name="value12">
</div>
</div>
</div>
</div>
<div class="spc">
</div>
<!--end-->
<div class="snip" id="sameo">
<p><b>Trainings and Certifications</b></p>
</div>
<div class="max" id="tark">
<p>0<br>
Not Done</p>
</div>
<div class="max" id="tark">
<p>1 <br>Some done with no/some impact
</p>
</div>
<div class="max" id="tark">
<p>2<br>
Trainings completed</p>
</div><div class="max" id="tark">
<p>3<br>
Trainings completed</p>
</div>
<div class="max" id="tark">
<p>4<br>
Trainings completed</p>
</div>
<!--fist set start-->
<div class="cont">
<div class="cn1">
<p>- Measured based on increase/decrease in quality from the last review periods (2016-17) closing quality for the account/corporate(s)					
- Drive continuous improvement culture on the floor					
- Documentation/quantification of the improvement initiative that has helped improve quality is mandatory. Improvements made should be sustainable and controls defined. FIF should show improvement i.e. reduction quarter on quarter					
- A minimum of 5% AOQ sampling by shift is compulsory through out the review period (online or offline)					
- In case corporate is already reporting higher external quality, reporting Manager to engage independent party for stricter AOQ sampling month on month and that becomes the quality performance of the individual					
- In case of multiple Planning Leads in a corporate, ownership can be shared or singled. Managers approval will be required					
- Drive process adherence or look at automated solution for process adherence leading to quality improvement					
</p>
</div>
<div class="gain">
<p>12%</p>
</div>
<div class="message">
<div class="num">
<input type="text" class="rbm" autocomplete="off" name="leaves" id="ssw" onkeyup=nano();><em id="base9"></em>
</div>
<div class="mark">
<input type="text" autocomplete="off" name="value13" id="rim">
</div>
<div class="dis" id="alss">
<input type ="text" class="area" autocomplete="off" name="value14">
</div>
</div>
</div>
</div>








<!--FOOTR------>
<div class="foot">
<div class="final">
<p> Total%<span class="dino"> 100%</span></p>
</div>
<div class="give">
<input type="submit" autocomplete="off" name="submit" value="SUBMIT" id="save">
</div>
</div>
</div>
</body>
</html>
