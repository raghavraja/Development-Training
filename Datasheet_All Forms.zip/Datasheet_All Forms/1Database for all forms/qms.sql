-- phpMyAdmin SQL Dump
-- version 4.4.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 01, 2018 at 01:06 PM
-- Server version: 5.6.26
-- PHP Version: 5.6.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `qms2`
--

-- --------------------------------------------------------

--
-- Table structure for table `alpha`
--

CREATE TABLE IF NOT EXISTS `alpha` (
  `employee` varchar(100) NOT NULL,
  `production` varchar(100) NOT NULL,
  `value1` varchar(100) NOT NULL,
  `value2` varchar(100) NOT NULL,
  `quality` varchar(100) NOT NULL,
  `value3` varchar(100) NOT NULL,
  `value4` varchar(100) NOT NULL,
  `certification` varchar(100) NOT NULL,
  `value5` varchar(100) NOT NULL,
  `value6` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `alpha`
--

INSERT INTO `alpha` (`employee`, `production`, `value1`, `value2`, `quality`, `value3`, `value4`, `certification`, `value5`, `value6`) VALUES
('1844', '1844', 'Outstanding', 'hello', '1844', 'Outstanding', 'hello', '1844', 'Outstanding', 'hello'),
('1844', '8754', 'Outstanding', 'hello', '1844', 'Outstanding', 'hello', '1844', 'Outstanding', 'hello');

-- --------------------------------------------------------

--
-- Table structure for table `data`
--

CREATE TABLE IF NOT EXISTS `data` (
  `employee` int(50) NOT NULL,
  `production` int(3) NOT NULL,
  `value1` varchar(100) NOT NULL,
  `value2` varchar(100) NOT NULL,
  `quality` varchar(100) NOT NULL,
  `value3` varchar(100) NOT NULL,
  `value4` varchar(100) NOT NULL,
  `certification` int(5) NOT NULL,
  `value5` varchar(50) NOT NULL,
  `value6` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `data`
--

INSERT INTO `data` (`employee`, `production`, `value1`, `value2`, `quality`, `value3`, `value4`, `certification`, `value5`, `value6`) VALUES
(1001, 4, 'Exceeds Expectations', 'i did smart work ', '99.2', 'Exceeds Expectations', 'focus on quality', 4, 'Outstanding', 'awards'),
(1002, 4, 'Exceeds Expectations', 'hello', '99.05', 'Exceeds Expectations', 'focus on quality', 4, 'Outstanding', 'awards'),
(0, 0, '', '', '', '', '', 0, '', ''),
(1844, 7, 'Outstanding', 'hello', '100', 'Outstanding', 'hello', 4, 'Outstanding', 'hello'),
(0, 0, '', '', '', '', '', 0, '', ''),
(1844, 5, 'Exceeds Expectations', 'hello', '100', 'Outstanding', 'hello', 5, 'Outstanding', 'hello'),
(1844, 9, 'Outstanding', 'hello', '100', 'Outstanding', 'hello', 8, 'Outstanding', 'hello'),
(1844, 58, 'Outstanding', 'hello', '100', 'Outstanding', 'hello', 50, 'Outstanding', 'hello'),
(1844, 100, 'Outstanding', 'hello', '100', 'Outstanding', 'hello', 100, 'Outstanding', 'hello'),
(1844, 100, 'Outstanding', 'hello', '100', 'Outstanding', 'hello', 100, 'Outstanding', 'hello'),
(1844, 100, 'Outstanding', 'hello', '100', 'Outstanding', 'hello', 100, 'Outstanding', 'hello'),
(1844, 100, 'Outstanding', 'hello', '100', 'Outstanding', 'hello', 100, 'Outstanding', 'hello'),
(1844, 100, 'Outstanding', 'hello', '1844', 'Outstanding', 'hello', 1844, 'Outstanding', 'hello'),
(1844, 100, 'Outstanding', 'hello', '1844', 'Outstanding', 'hello', 1844, 'Outstanding', 'hello'),
(1844, 100, 'Outstanding', 'hello', '20.52', 'Outstanding', 'hello', 0, 'Outstanding', '  ');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE IF NOT EXISTS `employee` (
  `id` int(11) NOT NULL,
  `uname` varchar(50) NOT NULL,
  `pass` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`id`, `uname`, `pass`) VALUES
(1844, 'rajaji', '12345'),
(1845, 'arun', '123456');

-- --------------------------------------------------------

--
-- Table structure for table `find`
--

CREATE TABLE IF NOT EXISTS `find` (
  `employee` varchar(100) NOT NULL,
  `production` varchar(100) NOT NULL,
  `value1` varchar(100) NOT NULL,
  `value2` varchar(100) NOT NULL,
  `quality` varchar(100) NOT NULL,
  `value3` varchar(100) NOT NULL,
  `value4` varchar(100) NOT NULL,
  `certification` varchar(100) NOT NULL,
  `value5` varchar(100) NOT NULL,
  `value6` varchar(100) NOT NULL,
  `training` varchar(100) NOT NULL,
  `value7` varchar(100) NOT NULL,
  `value8` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `find`
--

INSERT INTO `find` (`employee`, `production`, `value1`, `value2`, `quality`, `value3`, `value4`, `certification`, `value5`, `value6`, `training`, `value7`, `value8`) VALUES
('1844', '100', 'Outstanding', 'hello', '100', 'Outstanding', 'hello', '100', 'Outstanding', 'hello', '10', 'Outstanding', 'hello'),
('1844', '100', 'Outstanding', 'hello', '1844', 'Outstanding', 'hello', '1844', 'Outstanding', 'hello', '1844', 'Outstanding', 'hello');

-- --------------------------------------------------------

--
-- Table structure for table `list`
--

CREATE TABLE IF NOT EXISTS `list` (
  `employee` varchar(100) NOT NULL,
  `production` varchar(100) NOT NULL,
  `value1` varchar(100) NOT NULL,
  `value2` varchar(100) NOT NULL,
  `quality` varchar(100) NOT NULL,
  `value3` varchar(100) NOT NULL,
  `value4` varchar(100) NOT NULL,
  `certification` varchar(100) NOT NULL,
  `value5` varchar(100) NOT NULL,
  `value6` varchar(100) NOT NULL,
  `training` varchar(100) NOT NULL,
  `value7` varchar(100) NOT NULL,
  `value8` varchar(100) NOT NULL,
  `analysis` varchar(100) NOT NULL,
  `value9` varchar(100) NOT NULL,
  `value10` varchar(100) NOT NULL,
  `attendance` varchar(100) NOT NULL,
  `value11` varchar(100) NOT NULL,
  `value12` varchar(100) NOT NULL,
  `leaves` varchar(100) NOT NULL,
  `value13` varchar(100) NOT NULL,
  `value14` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `list`
--

INSERT INTO `list` (`employee`, `production`, `value1`, `value2`, `quality`, `value3`, `value4`, `certification`, `value5`, `value6`, `training`, `value7`, `value8`, `analysis`, `value9`, `value10`, `attendance`, `value11`, `value12`, `leaves`, `value13`, `value14`) VALUES
('1844', '58', 'Outstanding', 'hello', '100', 'Outstanding', 'hello', '100', 'Outstanding', 'hello', '100', 'Outstanding', 'hello', '100', 'Outstanding', 'hello', '0', 'Outstanding', '', '0', 'Outstanding', 'hello');

-- --------------------------------------------------------

--
-- Table structure for table `mask`
--

CREATE TABLE IF NOT EXISTS `mask` (
  `employee` varchar(100) NOT NULL,
  `production` varchar(100) NOT NULL,
  `value1` varchar(100) NOT NULL,
  `value2` varchar(100) NOT NULL,
  `quality` varchar(100) NOT NULL,
  `value3` varchar(100) NOT NULL,
  `value4` varchar(100) NOT NULL,
  `certification` varchar(100) NOT NULL,
  `value5` varchar(100) NOT NULL,
  `value6` varchar(100) NOT NULL,
  `training` varchar(100) NOT NULL,
  `value7` varchar(100) NOT NULL,
  `value8` varchar(100) NOT NULL,
  `analysis` varchar(100) NOT NULL,
  `value9` varchar(100) NOT NULL,
  `value10` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mask`
--

INSERT INTO `mask` (`employee`, `production`, `value1`, `value2`, `quality`, `value3`, `value4`, `certification`, `value5`, `value6`, `training`, `value7`, `value8`, `analysis`, `value9`, `value10`) VALUES
('1844', '8754', 'Outstanding', 'HELLO', '1844', 'Outstanding', 'hello', '1844', 'Outstanding', 'hello', '1844', 'Outstanding', 'hello', '1844', 'Outstanding', 'hello');

-- --------------------------------------------------------

--
-- Table structure for table `sheet`
--

CREATE TABLE IF NOT EXISTS `sheet` (
  `employee` varchar(100) NOT NULL,
  `production` varchar(100) NOT NULL,
  `value1` varchar(100) NOT NULL,
  `value2` varchar(100) NOT NULL,
  `quality` varchar(100) NOT NULL,
  `value3` varchar(100) NOT NULL,
  `value4` varchar(100) NOT NULL,
  `certification` varchar(100) NOT NULL,
  `value5` varchar(100) NOT NULL,
  `value6` varchar(100) NOT NULL,
  `training` varchar(100) NOT NULL,
  `value7` varchar(100) NOT NULL,
  `value8` varchar(100) NOT NULL,
  `analysis` varchar(100) NOT NULL,
  `value9` varchar(100) NOT NULL,
  `value10` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sheet`
--

INSERT INTO `sheet` (`employee`, `production`, `value1`, `value2`, `quality`, `value3`, `value4`, `certification`, `value5`, `value6`, `training`, `value7`, `value8`, `analysis`, `value9`, `value10`) VALUES
('1844', '50', 'Outstanding', 'hello', '100', 'Outstanding', 'hello', '100', 'Outstanding', 'hello', '100', 'Outstanding', '100', '100', 'Outstanding', 'hwlll'),
('1844', '1844', 'Outstanding', 'hello', '1844', 'Outstanding', 'hello', '1844', 'Outstanding', 'hello', '1844', 'Outstanding', 'hello', '1844', 'Outstanding', 'helo'),
('1844', '1844', 'Outstanding', 'hello', '1844', 'Outstanding', 'hello', '1844', 'Outstanding', 'hello', '17844', 'Outstanding', 'helo', '1844', 'Outstanding', 'hello'),
('1844', '100', 'Outstanding', 'hello', '1844', 'Outstanding', 'hello', '1844', 'Outstanding', 'hello', '1844', 'Outstanding', 'hello', '1844', 'Outstanding', 'hello');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
