<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Senior CSE KRA_2017-18</title>
<link rel="stylesheet" type="text/css" href="datastylesheet.css" />
<script src="source.js"></script>
<script src="valid.js"></script>
</head>
<body>
<div id="wrapper">
<div class="header">
<div class="qms">
<h3>Senior CSE KRA_2017-18</h3>
</div>
<div class="apprisal">
<div class="para" id="fm">
<p>Parameters</p>
</div>
<div class="rating">
<p>Rating</p>
</div>
<div class="quality">
<div class="box1">
<p>Ratings</p>
</div>
<div class="box2">
<div class="min">
<p>min</p>
</div>
<div class="max">
<p>max</p>
</div>
<div class="Weightage">
<p>Weightage</p>
</div>
</div>
</div>
</div>
<div class="spc">
<h5>Communication (Accuracy, Timeliness, Effectiveness)</h5>
</div>
<!--fist set start-->
<div class="cont">
<div class="cn1">
<p>Measured based on the monthly message review exercise done by Managers. Parameters assessed:<br>
1. Understanding  2. Closure   3. Language accuracy and appropriateness<br>
- To consist of reviews of 40 pieces of communication per month per support team member, to be submitted for validation at the rate of 10 per  week<br>
- To be made up of 50% JD messages and 50% emails. If a particular account does not provide scope for the necessary number of reviewable emails, other corporate specific methods of communication should be taken into account (e.g. issue trackers, escalation responses).<br>
- Template, copy / paste communications and acknowledgements  are not to  be submitted for review<br>
- A full 2 points are to be deducted for any errors. There are no partial deductions</p>
</div>
<div class="cn3">
<table>
<tr>
<td>Outstanding</td>
</tr>
<tr>
<td>Exceeds Expectations</td>
</tr>
<tr>
<td>Meets Expectations</td>
</tr>
<tr>
<td>Mostly Meets Expectations</td>
</tr>
<tr>
<td class="ark">Does not Meet Expectations</td>
</tr>
</table>
</div>
<div class="cn4">
<div class="cn5">
<table class="score">
<tr>
<td colspan="2">>95.01%</td>
</tr>
<tr>
<td>90.01%</td>
<td>95.00%</td>
</tr>
<tr>
<td>85.01%</td>
<td>89.00%</td>
</tr>
<tr>
<td>85.01%</td>
<td>90.00%</td>
</tr>
<tr>
<td class="ark" colspan="2">
Below 80%</td>
</tr>
</table>
</div>
<div class="cn6">
<div class="hrw">
<p>45%</p>
</div>
</div>
</div>
<div class="message">
<form name="fname" onsubmit="return validateForm()" method="post" action="insert.php">

<div class="num">
<input type="text" name="employee" id="employee" autocomplete="off" placeholder="Employee Id"><em id="info"></em>
<input type="text" class="rbm" name="production" autocomplete="off" id="parameters" onkeyup=myFunction();><em id="base"></em>
</div>
<div class="mark">
<input type="text" id="score" autocomplete="off" name="value1">
</div>
<div class="dis" id="description">
<input type="text" class="area" autocomplete="off" name="value2"><em id="base2"></em>
</div>
</div>
</div>
<div class="spc">
<h5>Reporting</h5>
</div>
<!--first set End-->
<!--second star-->
<div class="second">
<div class="cont">
<div class="cn1">
<p>Reflects accuracy, timeliness and complexity of reporting undertaken. Includes internal reports if provided to an audience including managers<br>
- Demonstrates detailed understanding of all internal and external reports - purpose/objective, relationship, and impact on the clients end. Reports also includes Production<br>
- Involved in sending a report at an acceptable frequency to gauge this. There should not be repeated instances of issues identified or feedback given.<br>
- Accountable for accuracy of any/all reports both internal / external sent by self and direct reports. Measurement/lapse count will be based on instances identified by Manager and customer feedback<br>
- Strong understanding of productivity tools in MS Excel to generate and deliver reports on time or agreed timeframe with no delays.<br>
Measurement based on - • Accuracy and timeliness of data supplied • Intelligence & analysis - Able to summarise, provide insights and draw conclusions from the data collected</p>
</div>
<div class="cn3">
<table>
<tr>
<td>Outstanding</td>
</tr>
<tr>
<td>Exceeds Expectations</td>
</tr>
<tr>
<td>Meets Expectations</td>
</tr>
<tr>
<td>Mostly Meets Expectations</td>
</tr>
<tr>
<td class="ark">Does not Meet Expectations</td>
</tr>
</table>
</div>
<div class="cn4">
<div class="cn5">
<table class="score">
<tr>
<td colspan="2">>90.01</td>
</tr>
<tr>
<td>80.01%</td>
<td>90.00%</td>
</tr>
<tr>
<td>70.01%</td>
<td>80.00%</td>
</tr>
<tr>
<td>60.01%</td>
<td>70.00%</td>
</tr>
<tr>
<td class="ark" colspan="2">Below 55%</td>
</tr>
</table>
</div>
<div class="cn6">
<div class="hrw">
<p>15%</p>
</div>
</div>
</div>
<div class="message">
<div class="num">
<input type="text" class="rbm" name="quality" autocomplete="off" id="ark" onkeyup=gama();><em id="base3"></em>
</div>
<div class="mark">
<input type="text" name="value3" autocomplete="off" id="ssm">
</div>
<div class="dis" id="max">
<input type="text" name="value4" autocomplete="off" class="area"><em id="base4"></em>
</div>
</div>
</div>
</div>
<div class="spc">
<h5>Initiatives</h5>
</div>
<!--end-->
<div class="second">
<div class="cont">
<div class="cn1">
<p>• Initiatives measured based on ideas shared and documented with the reporting manager and result achieved.<br>
• Evolves through self learning and contributes towards the process improvement initiatives on the floor.<br>
<b>Initiatives Undertaken*</b> - Initiatives that are outside the boundaries of existing expectations under the individual's KRA. Does not include tasks or projects assigned by lead or manager.<br>
- maximum of 1 pt for each self learning initiative or certification achieved<br>
- maximum of 5 pts per process initiative undertaken<br>
*CSE can only receive points once for undertaking an initiative<br>
<b>Progress shown</b> - Progress must be documented and presented to Lead/Manager in the appropriate<br>
<b>Results Achieved**</b> - Determined by 1. Any measureable results achieved   2. Documented and closed<br>
** Marks to be awarded only once there is evidence of effectiveness</p>
</div>
<div class="cn3">
<table>
<tr>
<td>Outstanding</td>
</tr>
<tr>
<td>Exceeds Expectations</td>
</tr>
<tr>
<td>Meets Expectations</td>
</tr>
<tr>
<td>Mostly Meets Expectations</td>
</tr>
<tr>
<td class="ark">Does not Meet Expectations</td>
</tr>
</table>
</div>
<div class="cn4">
<div class="cn5">
<table class="score">
<tr>
<td colspan="2">>85.01%</td>
</tr>
<tr>
<td>75.01%</td>
<td>85.00%</td>
</tr>
<tr>
<td>65.01%</td>
<td>75.00%</td>
</tr>
<tr>
<td>55.01%</td>
<td>65.00%</td>
</tr>
<tr>
<td class="ark" colspan="2">Below 50%</td>
</tr>
</table>
</div>
<div class="cn6">
<div class="hrw">
<p>10%</p>
</div>
</div>
</div>
<div class="message">
<div class="num">
<input type="text" class="rbm" name="certification" autocomplete="off" id="before" onkeyup=sky();><em id="base5"></em>
</div>
<div class="mark">
<input type="text" name="value5" autocomplete="off" id="alpha">
</div>
<div class="dis" id="marks">
<input type="text" class="area" name="value6" autocomplete="off" >
</div>
</div>
</div>
</div>
<div class="spc">
<h5>Overall effectiveness of communication</h5>
</div>
<div class="cont">
<div class="cn1">
<p> <b>Escalation Management</b> CSE to present at least one example per month of effective escalation/situation management.
Can involve all communication channels available. Review will be based on -
- Understanding and effective issue definition
- Effective solution based approach and judgment
- Closure and follow up (should include evidence of actions taken outside the communication thread and show results)
<b>Internal Team Communication</b> - Team work - ability to work with designers, leads, peers in the team
- The team trusts the individual's judgment
- Consistent and clear information is passed
- Process changes (internal or client) are effectively documented and communicated
<b>Domain and product expertise</b> - Demonstrates the ability to provide first line support and effectively manage creative
(where applicable) and technical queries or issues (internal and client facing).
with the JDX product suite and integration process, and effectively escalate if required.</p>
</div>
<div class="cn3">
<table>
<tr>
<td>Outstanding</td>
</tr>
<tr>
<td>Exceeds Expectations</td>
</tr>
<tr>
<td>Meets Expectations</td>
</tr>
<tr>
<td>Mostly Meets Expectations</td>
</tr>
<tr>
<td class="ark">Does not Meet Expectations</td>
</tr>
</table>
</div>
<div class="cn4">
<div class="cn5">
<table class="score">
<tr>
<td colspan="2">>95.01%</td>
</tr>
<tr>
<td>85.01%</td>
<td>95.00%</td>
</tr>
<tr>
<td>75.01%</td>
<td>85.00%</td>
</tr>
<tr>
<td>65.01%</td>
<td>75.00%</td>
</tr>
<tr>
<td class="ark" colspan="2">Below 65%</td>
</tr>
</table>
</div>
<div class="cn6">
<div class="hrw">
<p>20%</p>
</div>
</div>
</div>
<div class="message">
<div class="num">
<input type="text" class="rbm" name="training" autocomplete="off" id="ball" onkeyup=beta();><em id="base6"></em>
</div>
<div class="mark">
<input type="text" name="value7" id="king" autocomplete="off">

</div>
<div class="dis" id="mrc">
<input type = "text" class="area" name="value8" autocomplete="off">
</div>
</div>
</div>
<div class="spc">
<h5>Attendance</h5>
</div>
<!--first set End-->
<!--second star-->
<div class="second">
<div class="cont">
<div class="cn1">
<p>* Un Planned Leave
1. Any instance of uninformed leaves or LOP<br>
2. Leaves applied outside of advance notice mentioned in the leave policy<br>
3. Unable to come back on the said days after planned leave<br>
4. Extension to planned leaves<br>
5. Calling out last minute or a day before scheduled shift<br>
6. Sick leave without doctors certificate<br>
7. Others at the discretion of the CM or OM as applicable. </p>
</div>
<div class="cn3">
<table>
<tr>
<td>Outstanding</td>
</tr>
<tr>
<td>Exceeds Expectations</td>
</tr>
<tr>
<td>Meets Expectations</td>
</tr>
<tr>
<td>Mostly Meets Expectations</td>
</tr>
<tr>
<td class="ark">Does not Meet Expectations</td>
</tr>
</table>
</div>
<div class="cn4">
<div class="cn5">
<table class="score">
<tr>
<td>0 Instance</td>
</tr>
<tr>
<td>1 Instance</td>
</tr>
<tr>
<td>2 Instance</td>
</tr>
<tr>
<td>3 Instance</td>
</tr>
<tr>
<td class="ark">>3 Instance</td>
</tr>
</table>
</div>
<div class="cn6">
<div class="hrw">
<p>15%</p>
</div>
</div>
</div>
<div class="message">
<div class="num">
<input type="text" class="rbm" name="analysis" id="blank" autocomplete="off" onkeyup=ray();><em id="base7"></em>
</div>
<div class="mark">
<input type="text" name="value9" autocomplete="off" id="fit">
</div>
<div class="dis" id="shine">
<input type="text" class="area" autocomplete="off" name="value10">
</div>
</div>
</div>
</div>
<!--end-->
</div>
<div class="foot">
<div class="final">
<p> Total%<span class="dino"> 100%</span></p>
</div>
<div class="give">
<input type="submit" autocomplete="off" name="submit" value="SUBMIT" id="save">
</div>
</div>
</div>
</body>
</html>
