function myFunction()
{
	var name = document.getElementById("parameters");
	var strike = name.value;
	
	if(strike == 1)
	{
		document.getElementById("score").innerHTML="Mostly Meets Expectations";
		document.getElementById("description").style.display = "none";
	}
	
	else if (strike == 2)
	{
		document.getElementById("score").innerHTML="Meets Expectations";
		document.getElementById("description").style.display = "none";
	}
	
	else if (strike == 3)
		
		{
			document.getElementById("score").innerHTML="Exceeds Expectations";
			document.getElementById("description").style.display = "block";
		}
	
	else if (strike  == 4)
		
		{
			document.getElementById("score").innerHTML="Outstanding";
			document.getElementById("description").style.display = "block";
		}
	
	else
	{
		document.getElementById("score").innerHTML="";
	}
		
}

/*first set end */

		
/* second set end */












